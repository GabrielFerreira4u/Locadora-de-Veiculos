import { ListaCrud } from "../../components/ListaCrud";
import type { Coluna } from "../../components/Table";
import type { Categoria } from "../../models/Categoria";
import { moeda } from "../../models/formatadores";
import { categoriaService } from "../../service/categoriaService";
import { modeloService } from "../../service/modeloService";

const colunas: Coluna<Categoria>[] = [
  { titulo: "ID", render: (c) => c.id },
  { titulo: "Nome", render: (c) => c.nome },
  { titulo: "Valor da diária", render: (c) => moeda(c.valorLocacao) },
];

export function CategoriaList() {
  return (
    <ListaCrud
      titulo="Categorias"
      nomeEntidade="Categoria"
      rotaBase="/categorias"
      service={categoriaService}
      colunas={colunas}
      descrever={(c) => c.nome}
      dependentes={async (c) => {
        const qtd = (await modeloService.listar()).filter((m) => m.categoriaId === c.id).length;
        return qtd > 0 ? `existem ${qtd} modelo(s) vinculado(s) a ela` : null;
      }}
    />
  );
}

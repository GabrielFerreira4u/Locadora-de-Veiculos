import { FormCadastro } from "../../components/FormCadastro";
import { Input } from "../../components/Input";
import { categoriaInicial } from "../../models/Categoria";
import type { Categoria } from "../../models/Categoria";
import { categoriaService } from "../../service/categoriaService";
import { useCadastro } from "../useCadastro";

export function CategoriaForm() {
  const { id, obj, erros, erroApi, setErroApi, alterar, salvar, cancelar } = useCadastro<Categoria>({
    service: categoriaService,
    inicial: categoriaInicial,
    rotaLista: "/categorias",
    nome: "Categoria",
    validar: (c) => ({
      nome: c.nome.trim() === "" ? "Informe o nome da categoria." : "",
      valorLocacao: c.valorLocacao <= 0 ? "O valor da diária deve ser maior que zero." : "",
    }),
  });

  return (
    <FormCadastro titulo={id ? "Editar categoria" : "Nova categoria"} erroApi={erroApi}
      onCloseErro={() => setErroApi("")} onSubmit={salvar} onCancel={cancelar}>
      <Input label="Nome" name="nome" value={obj.nome} onChange={alterar} error={erros.nome} />
      <Input label="Valor da diária (R$)" name="valorLocacao" type="number" min={0} step={0.01}
        value={obj.valorLocacao} onChange={alterar} error={erros.valorLocacao} />
    </FormCadastro>
  );
}

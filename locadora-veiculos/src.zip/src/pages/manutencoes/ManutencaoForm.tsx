import { useEffect, useState } from "react";
import { FormCadastro } from "../../components/FormCadastro";
import { Input } from "../../components/Input";
import { Select } from "../../components/Select";
import type { OpcaoSelect } from "../../components/Select";
import { manutencaoInicial } from "../../models/Manutencao";
import type { Manutencao } from "../../models/Manutencao";
import { manutencaoService } from "../../service/manutencaoService";
import { veiculoService } from "../../service/veiculoService";
import { useCadastro } from "../useCadastro";

export function ManutencaoForm() {
  const [veiculos, setVeiculos] = useState<OpcaoSelect[]>([]);

  const { id, obj, erros, erroApi, setErroApi, alterar, salvar, cancelar } = useCadastro<Manutencao>({
    service: manutencaoService,
    inicial: manutencaoInicial,
    rotaLista: "/manutencoes",
    nome: "Manutenção",
    validar: (m) => ({
      veiculoId: m.veiculoId === "" ? "Selecione o veículo." : "",
      data: m.data === "" ? "Informe a data." : "",
      descricao: m.descricao.trim() === "" ? "Informe a descrição." : "",
      valor: m.valor < 0 ? "O valor não pode ser negativo." : "",
    }),
  });

  useEffect(() => {
    void veiculoService.listar().then((lista) =>
      setVeiculos(lista.map((v) => ({ value: v.id ?? "", label: `${v.placa} - ${v.cor}` })))
    );
  }, []);

  return (
    <FormCadastro titulo={id ? "Editar manutenção" : "Nova manutenção"} erroApi={erroApi}
      onCloseErro={() => setErroApi("")} onSubmit={salvar} onCancel={cancelar}>
      <Select label="Veículo" name="veiculoId" value={obj.veiculoId} options={veiculos} onChange={alterar} error={erros.veiculoId} />
      <Input label="Data" name="data" type="date" value={obj.data} onChange={alterar} error={erros.data} />
      <Input label="Descrição" name="descricao" value={obj.descricao} onChange={alterar} error={erros.descricao} />
      <Input label="Valor (R$)" name="valor" type="number" min={0} step={0.01} value={obj.valor} onChange={alterar} error={erros.valor} />
    </FormCadastro>
  );
}

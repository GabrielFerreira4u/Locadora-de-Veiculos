import { useEffect, useState } from "react";
import { ListaCrud } from "../../components/ListaCrud";
import { Select } from "../../components/Select";
import type { OpcaoSelect } from "../../components/Select";
import type { Coluna } from "../../components/Table";
import { formatarData, moeda } from "../../models/formatadores";
import type { Manutencao } from "../../models/Manutencao";
import type { Veiculo } from "../../models/Veiculo";
import { manutencaoService } from "../../service/manutencaoService";
import { veiculoService } from "../../service/veiculoService";

export function ManutencaoList() {
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [veiculoFiltro, setVeiculoFiltro] = useState("");

  useEffect(() => {
    void veiculoService.listar().then(setVeiculos);
  }, []);

  const placa = (id: string): string => veiculos.find((v) => v.id === id)?.placa ?? "-";
  const opcoes: OpcaoSelect[] = veiculos.map((v) => ({ value: v.id ?? "", label: v.placa }));

  const colunas: Coluna<Manutencao>[] = [
    { titulo: "Data", render: (m) => formatarData(m.data) },
    { titulo: "Veículo", render: (m) => placa(m.veiculoId) },
    { titulo: "Descrição", render: (m) => m.descricao },
    { titulo: "Valor", render: (m) => moeda(m.valor) },
  ];

  return (
    <ListaCrud
      titulo="Manutenções"
      nomeEntidade="Manutenção"
      rotaBase="/manutencoes"
      service={manutencaoService}
      colunas={colunas}
      descrever={(m) => m.descricao}
      filtro={(m) => veiculoFiltro === "" || m.veiculoId === veiculoFiltro}
      topo={
        <Select label="Histórico por veículo" name="filtroVeiculo" value={veiculoFiltro} options={opcoes}
          placeholder="Todos os veículos" onChange={(e) => setVeiculoFiltro(e.target.value)} />
      }
    />
  );
}

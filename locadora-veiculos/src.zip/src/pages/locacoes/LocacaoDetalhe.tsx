import { useCallback, useEffect, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { Alert } from "../../components/Alert";
import { Button } from "../../components/Button";
import { Card } from "../../components/Card";
import { Input } from "../../components/Input";
import { Modal } from "../../components/Modal";
import { Select } from "../../components/Select";
import { Table } from "../../components/Table";
import type { Coluna } from "../../components/Table";
import type { Categoria } from "../../models/Categoria";
import type { Cliente } from "../../models/Cliente";
import { formatarData, hojeISO, moeda } from "../../models/formatadores";
import { corStatusLocacao } from "../../models/Locacao";
import type { Locacao } from "../../models/Locacao";
import type { Contrato } from "../../models/Contrato";
import type { Marca } from "../../models/Marca";
import type { Modelo } from "../../models/Modelo";
import type { NotaFiscal } from "../../models/NotaFiscal";
import { formasPagamento, pagamentoInicial, statusPagamento } from "../../models/Pagamento";
import type { Pagamento } from "../../models/Pagamento";
import type { Veiculo } from "../../models/Veiculo";
import type { Vistoria } from "../../models/Vistoria";
import { categoriaService } from "../../service/categoriaService";
import { clienteService } from "../../service/clienteService";
import { contratoService } from "../../service/contratoService";
import { locacaoService } from "../../service/locacaoService";
import { marcaService } from "../../service/marcaService";
import { modeloService } from "../../service/modeloService";
import { notaFiscalService } from "../../service/notaFiscalService";
import { pagamentoService } from "../../service/pagamentoService";
import { veiculoService } from "../../service/veiculoService";
import { vistoriaService } from "../../service/vistoriaService";

interface Dados {
  locacao: Locacao;
  cliente: Cliente;
  veiculo: Veiculo;
  modelo: Modelo;
  marca: Marca;
  categoria: Categoria;
  contrato?: Contrato;
  vistorias: Vistoria[];
  pagamentos: Pagamento[];
  nota?: NotaFiscal;
}

interface Mensagem {
  type: "success" | "danger" | "warning";
  texto: string;
}

const colunasVistoria: Coluna<Vistoria>[] = [
  { titulo: "Tipo", render: (v) => (v.tipo === "RETIRADA" ? "Retirada" : "Devolução") },
  { titulo: "Data", render: (v) => formatarData(v.data) },
  { titulo: "Km", render: (v) => v.km.toLocaleString("pt-BR") },
  { titulo: "Combustível", render: (v) => v.nivelCombustivel },
  { titulo: "Observações", render: (v) => v.observacoes || "-" },
];

const colunasPagamento: Coluna<Pagamento>[] = [
  { titulo: "Data", render: (p) => formatarData(p.data) },
  { titulo: "Valor", render: (p) => moeda(p.valor) },
  { titulo: "Forma", render: (p) => formasPagamento.find((f) => f.value === p.forma)?.label ?? p.forma },
  { titulo: "Status", render: (p) => statusPagamento.find((s) => s.value === p.status)?.label ?? p.status },
];

export function LocacaoDetalhe() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const textoInicial = (location.state as { mensagem?: string } | null)?.mensagem;

  const [dados, setDados] = useState<Dados | null>(null);
  const [mensagem, setMensagem] = useState<Mensagem | null>(textoInicial ? { type: "success", texto: textoInicial } : null);
  const [pagamento, setPagamento] = useState<Pagamento>({ ...pagamentoInicial, data: hojeISO() });
  const [erroValor, setErroValor] = useState("");
  const [confirmaCancelar, setConfirmaCancelar] = useState(false);

  const carregar = useCallback(async () => {
    if (!id) return;
    try {
      const locacao = await locacaoService.buscarPorId(id);
      const [cliente, veiculo, contratos, vistorias, pagamentos, notas] = await Promise.all([
        clienteService.buscarPorId(locacao.clienteId),
        veiculoService.buscarPorId(locacao.veiculoId),
        contratoService.listar(),
        vistoriaService.listar(),
        pagamentoService.listar(),
        notaFiscalService.listar(),
      ]);
      const modelo = await modeloService.buscarPorId(veiculo.modeloId);
      const [marca, categoria] = await Promise.all([
        marcaService.buscarPorId(modelo.marcaId),
        categoriaService.buscarPorId(modelo.categoriaId),
      ]);
      setDados({
        locacao, cliente, veiculo, modelo, marca, categoria,
        contrato: contratos.find((c) => c.locacaoId === id),
        vistorias: vistorias.filter((v) => v.locacaoId === id),
        pagamentos: pagamentos.filter((p) => p.locacaoId === id),
        nota: notas.find((n) => n.locacaoId === id),
      });
    } catch {
      setMensagem({ type: "danger", texto: "Locação não encontrada ou API indisponível." });
    }
  }, [id]);

  useEffect(() => {
    void carregar();
  }, [carregar]);

  const alterarPagamento = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const numerico = e.target instanceof HTMLInputElement && e.target.type === "number";
    setPagamento({ ...pagamento, [name]: numerico ? Number(value) : value });
    setErroValor("");
  };

  // RF12: vários pagamentos por locação
  const registrarPagamento = async (e: FormEvent) => {
    e.preventDefault();
    if (!id) return;
    if (pagamento.valor <= 0) return setErroValor("O valor deve ser maior que zero.");
    try {
      await pagamentoService.criar({ ...pagamento, locacaoId: id });
      setPagamento({ ...pagamentoInicial, data: hojeISO() });
      setMensagem({ type: "success", texto: "Pagamento registrado." });
      await carregar();
    } catch {
      setMensagem({ type: "danger", texto: "Erro ao registrar o pagamento." });
    }
  };

  // RF13 + RN05: nota fiscal só para locação finalizada, no máximo uma por locação
  const emitirNota = async () => {
    if (!dados || !id) return;
    if (dados.locacao.status !== "FINALIZADA") {
      return setMensagem({ type: "danger", texto: "A nota fiscal só pode ser emitida para locações finalizadas." });
    }
    if (dados.nota) return setMensagem({ type: "warning", texto: "Esta locação já possui nota fiscal." });
    try {
      await notaFiscalService.criar({
        numero: `NF-${Date.now()}`, serie: "1", dataEmissao: hojeISO(), valor: dados.locacao.valorTotal, locacaoId: id,
      });
      setMensagem({ type: "success", texto: "Nota fiscal emitida." });
      await carregar();
    } catch {
      setMensagem({ type: "danger", texto: "Erro ao emitir a nota fiscal." });
    }
  };

  const cancelarLocacao = async () => {
    setConfirmaCancelar(false);
    if (!dados || !id) return;
    try {
      await locacaoService.atualizar(id, { ...dados.locacao, status: "CANCELADA" });
      setMensagem({ type: "success", texto: "Locação cancelada." });
      await carregar();
    } catch {
      setMensagem({ type: "danger", texto: "Erro ao cancelar a locação." });
    }
  };

  if (!dados) {
    return mensagem ? <Alert type={mensagem.type} message={mensagem.texto} /> : <p className="text-muted">Carregando...</p>;
  }

  const { locacao, cliente, veiculo, modelo, marca, categoria, contrato, vistorias, pagamentos, nota } = dados;
  const totalPago = pagamentos.filter((p) => p.status === "PAGO").reduce((soma, p) => soma + p.valor, 0);

  return (
    <>
      {mensagem && <Alert type={mensagem.type} message={mensagem.texto} onClose={() => setMensagem(null)} />}

      <Card title="Locação">
        <div className="row">
          <div className="col-md-6">
            <p><strong>Status:</strong> <span className={`badge text-bg-${corStatusLocacao[locacao.status]}`}>{locacao.status}</span></p>
            <p><strong>Retirada:</strong> {formatarData(locacao.dataRetirada)}</p>
            <p><strong>Devolução prevista:</strong> {formatarData(locacao.dataDevolucaoPrevista)}</p>
            <p><strong>Devolução real:</strong> {formatarData(locacao.dataDevolucaoReal)}</p>
          </div>
          <div className="col-md-6">
            <p><strong>Km retirada:</strong> {locacao.kmRetirada.toLocaleString("pt-BR")}</p>
            <p><strong>Km devolução:</strong> {locacao.kmDevolucao?.toLocaleString("pt-BR") ?? "-"}</p>
            <p><strong>Valor {locacao.status === "FINALIZADA" ? "total" : "previsto"}:</strong> {moeda(locacao.valorTotal)}</p>
            <p><strong>Total pago:</strong> {moeda(totalPago)}</p>
          </div>
        </div>
        <div className="d-flex gap-2 flex-wrap">
          {locacao.status === "ABERTA" && (
            <>
              <Button label="Registrar devolução" variant="success" onClick={() => navigate(`/locacoes/${id}/devolucao`)} />
              <Button label="Cancelar locação" variant="danger" onClick={() => setConfirmaCancelar(true)} />
            </>
          )}
          <Button label="Voltar" variant="secondary" onClick={() => navigate("/locacoes")} />
        </div>
      </Card>

      <div className="row">
        <div className="col-md-6">
          <Card title="Cliente">
            <p><strong>Nome:</strong> {cliente.nome}</p>
            <p><strong>CPF:</strong> {cliente.cpf}</p>
            <p><strong>CNH:</strong> {cliente.cnh} (validade {formatarData(cliente.validadeCnh)})</p>
            <p className="mb-0"><strong>Contato:</strong> {cliente.telefone} - {cliente.email}</p>
          </Card>
        </div>
        <div className="col-md-6">
          <Card title="Veículo">
            <p><strong>Veículo:</strong> {marca.nome} {modelo.nome} ({modelo.ano})</p>
            <p><strong>Placa:</strong> {veiculo.placa} - {veiculo.cor}</p>
            <p><strong>Categoria:</strong> {categoria.nome}</p>
            <p className="mb-0"><strong>Diária:</strong> {moeda(categoria.valorLocacao)}</p>
          </Card>
        </div>
      </div>

      <Card title="Contrato">
        {contrato ? (
          <>
            <p><strong>Número:</strong> {contrato.numero} - emitido em {formatarData(contrato.dataEmissao)}</p>
            <p className="mb-0">{contrato.termos}</p>
          </>
        ) : (
          <p className="text-muted mb-0">Nenhum contrato encontrado.</p>
        )}
      </Card>

      <Card title="Vistorias">
        <Table columns={colunasVistoria} data={vistorias} mensagemVazia="Nenhuma vistoria registrada." />
      </Card>

      <Card title="Pagamentos">
        <Table columns={colunasPagamento} data={pagamentos} mensagemVazia="Nenhum pagamento registrado." />
        {locacao.status !== "CANCELADA" && (
          <form onSubmit={registrarPagamento} noValidate>
            <div className="row">
              <div className="col-md-3">
                <Input label="Data" name="data" type="date" value={pagamento.data} onChange={alterarPagamento} />
              </div>
              <div className="col-md-3">
                <Input label="Valor (R$)" name="valor" type="number" min={0} step={0.01} value={pagamento.valor}
                  onChange={alterarPagamento} error={erroValor} />
              </div>
              <div className="col-md-3">
                <Select label="Forma" name="forma" value={pagamento.forma} options={formasPagamento}
                  onChange={alterarPagamento} placeholder="Selecione..." />
              </div>
              <div className="col-md-3">
                <Select label="Status" name="status" value={pagamento.status} options={statusPagamento}
                  onChange={alterarPagamento} placeholder="Selecione..." />
              </div>
            </div>
            <Button label="Registrar pagamento" type="submit" />
          </form>
        )}
      </Card>

      <Card title="Nota fiscal">
        {nota ? (
          <>
            <p><strong>Número:</strong> {nota.numero} - série {nota.serie}</p>
            <p><strong>Emissão:</strong> {formatarData(nota.dataEmissao)}</p>
            <p className="mb-0"><strong>Valor:</strong> {moeda(nota.valor)}</p>
          </>
        ) : (
          <>
            <p className="text-muted">
              {locacao.status === "FINALIZADA" ? "Nota fiscal ainda não emitida." : "A nota fiscal só pode ser emitida após finalizar a locação."}
            </p>
            <Button label="Emitir nota fiscal" variant="warning" onClick={emitirNota} disabled={locacao.status !== "FINALIZADA"} />
          </>
        )}
      </Card>

      <Modal show={confirmaCancelar} title="Cancelar locação" message="Deseja realmente cancelar esta locação?"
        confirmLabel="Cancelar locação" onClose={() => setConfirmaCancelar(false)} onConfirm={cancelarLocacao} />
    </>
  );
}

import { useEffect, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Alert } from "../../components/Alert";
import { Button } from "../../components/Button";
import { Card } from "../../components/Card";
import { Input } from "../../components/Input";
import { Select } from "../../components/Select";
import { TextArea } from "../../components/TextArea";
import { agoraLocal, moeda } from "../../models/formatadores";
import { calcularDiarias, calcularValorLocacao } from "../../models/Locacao";
import type { Locacao } from "../../models/Locacao";
import type { Veiculo } from "../../models/Veiculo";
import { niveisCombustivel } from "../../models/Vistoria";
import type { NivelCombustivel } from "../../models/Vistoria";
import { categoriaService } from "../../service/categoriaService";
import { locacaoService } from "../../service/locacaoService";
import { modeloService } from "../../service/modeloService";
import { veiculoService } from "../../service/veiculoService";
import { vistoriaService } from "../../service/vistoriaService";

export function DevolucaoForm() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [locacao, setLocacao] = useState<Locacao | null>(null);
  const [veiculo, setVeiculo] = useState<Veiculo | null>(null);
  const [valorDiaria, setValorDiaria] = useState(0);
  const [dataReal, setDataReal] = useState(agoraLocal());
  const [kmDevolucao, setKmDevolucao] = useState(0);
  const [combustivel, setCombustivel] = useState<NivelCombustivel>("CHEIO");
  const [observacoes, setObservacoes] = useState("");
  const [erros, setErros] = useState<Record<string, string>>({});
  const [erroApi, setErroApi] = useState("");

  useEffect(() => {
    if (!id) return;
    (async () => {
      const loc = await locacaoService.buscarPorId(id);
      const v = await veiculoService.buscarPorId(loc.veiculoId);
      const modelo = await modeloService.buscarPorId(v.modeloId);
      const categoria = await categoriaService.buscarPorId(modelo.categoriaId);
      setLocacao(loc);
      setVeiculo(v);
      setValorDiaria(categoria.valorLocacao);
      setKmDevolucao(loc.kmRetirada);
    })().catch(() => setErroApi("Locação não encontrada ou API indisponível."));
  }, [id]);

  const dataValida = locacao !== null && dataReal >= locacao.dataRetirada;
  // RF11: recalcula o valor total com a data real de devolução
  const valorTotal = locacao && dataValida ? calcularValorLocacao(locacao.dataRetirada, dataReal, valorDiaria) : 0;

  const finalizar = async (e: FormEvent) => {
    e.preventDefault();
    if (!locacao || !veiculo || !id) return;

    const novosErros: Record<string, string> = {
      dataReal: !dataValida ? "A devolução não pode ser anterior à retirada." : "",
      kmDevolucao: kmDevolucao < locacao.kmRetirada ? `O km de devolução não pode ser menor que o de retirada (${locacao.kmRetirada}).` : "", // RN04
    };
    setErros(novosErros);
    if (Object.values(novosErros).some(Boolean)) return;

    try {
      await vistoriaService.criar({
        tipo: "DEVOLUCAO", data: dataReal, km: kmDevolucao, nivelCombustivel: combustivel, observacoes, locacaoId: id,
      });
      await locacaoService.atualizar(id, {
        ...locacao, status: "FINALIZADA", dataDevolucaoReal: dataReal, kmDevolucao, valorTotal,
      });
      await veiculoService.atualizar(veiculo.id ?? "", { ...veiculo, kmRodado: kmDevolucao });
      navigate(`/locacoes/${id}`, { state: { mensagem: "Locação finalizada com sucesso." } });
    } catch {
      setErroApi("Erro ao finalizar a locação. Verifique se o JSON Server está rodando.");
    }
  };

  return (
    <Card title="Devolução do veículo">
      {erroApi && <Alert type="danger" message={erroApi} onClose={() => setErroApi("")} />}
      {locacao && locacao.status !== "ABERTA" && (
        <Alert type="warning" message="Esta locação não está aberta e não pode ser finalizada." />
      )}
      {locacao && (
        <form onSubmit={finalizar} noValidate>
          <Input label="Data de devolução real" name="dataReal" type="datetime-local" value={dataReal}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setDataReal(e.target.value)} error={erros.dataReal} />
          <Input label={`Km de devolução (retirada: ${locacao.kmRetirada})`} name="kmDevolucao" type="number" min={0}
            value={kmDevolucao} onChange={(e) => setKmDevolucao(Number(e.target.value))} error={erros.kmDevolucao} />
          <Select label="Nível de combustível" name="combustivel" value={combustivel} options={niveisCombustivel}
            onChange={(e) => setCombustivel(e.target.value as NivelCombustivel)} />
          <TextArea label="Observações da vistoria" name="observacoes" value={observacoes}
            onChange={(e) => setObservacoes(e.target.value)} />
          <Alert type="success" message={dataValida
            ? `${calcularDiarias(locacao.dataRetirada, dataReal)} diária(s) × ${moeda(valorDiaria)} = valor total ${moeda(valorTotal)}`
            : "Informe uma data de devolução válida."} />
          <div className="d-flex gap-2">
            <Button label="Finalizar locação" type="submit" variant="success" disabled={locacao.status !== "ABERTA"} />
            <Button label="Voltar" variant="secondary" onClick={() => navigate(`/locacoes/${id}`)} />
          </div>
        </form>
      )}
    </Card>
  );
}

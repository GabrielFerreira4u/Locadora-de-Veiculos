import { useEffect, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { Alert } from "../../components/Alert";
import { Button } from "../../components/Button";
import { Card } from "../../components/Card";
import { Input } from "../../components/Input";
import { Select } from "../../components/Select";
import type { OpcaoSelect } from "../../components/Select";
import { TextArea } from "../../components/TextArea";
import { cnhVencida } from "../../models/Cliente";
import type { Cliente } from "../../models/Cliente";
import { agoraLocal, hojeISO, moeda, nomeDe } from "../../models/formatadores";
import { calcularDiarias, calcularValorLocacao, locacaoInicial } from "../../models/Locacao";
import type { Locacao } from "../../models/Locacao";
import type { Manutencao } from "../../models/Manutencao";
import type { Categoria } from "../../models/Categoria";
import type { Marca } from "../../models/Marca";
import type { Modelo } from "../../models/Modelo";
import { calcularStatusVeiculo } from "../../models/Veiculo";
import type { Veiculo } from "../../models/Veiculo";
import { niveisCombustivel } from "../../models/Vistoria";
import type { NivelCombustivel } from "../../models/Vistoria";
import { categoriaService } from "../../service/categoriaService";
import { clienteService } from "../../service/clienteService";
import { contratoService } from "../../service/contratoService";
import { locacaoService } from "../../service/locacaoService";
import { manutencaoService } from "../../service/manutencaoService";
import { marcaService } from "../../service/marcaService";
import { modeloService } from "../../service/modeloService";
import { veiculoService } from "../../service/veiculoService";
import { vistoriaService } from "../../service/vistoriaService";

const TERMOS_PADRAO =
  "O locatário se compromete a devolver o veículo na data prevista, com o mesmo nível de combustível " +
  "da retirada, responsabilizando-se por multas e danos ocorridos durante o período de locação.";

interface FormLocacao {
  clienteId: string;
  veiculoId: string;
  dataRetirada: string;
  dataDevolucaoPrevista: string;
  nivelCombustivel: NivelCombustivel;
  observacoes: string;
}

export function LocacaoForm() {
  const navigate = useNavigate();
  const [form, setForm] = useState<FormLocacao>({
    clienteId: "",
    veiculoId: "",
    dataRetirada: agoraLocal(),
    dataDevolucaoPrevista: "",
    nivelCombustivel: "CHEIO",
    observacoes: "",
  });
  const [erros, setErros] = useState<Record<string, string>>({});
  const [erroApi, setErroApi] = useState("");

  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [modelos, setModelos] = useState<Modelo[]>([]);
  const [marcas, setMarcas] = useState<Marca[]>([]);
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [locacoes, setLocacoes] = useState<Locacao[]>([]);
  const [manutencoes, setManutencoes] = useState<Manutencao[]>([]);

  useEffect(() => {
    Promise.all([
      clienteService.listar(), veiculoService.listar(), modeloService.listar(), marcaService.listar(),
      categoriaService.listar(), locacaoService.listar(), manutencaoService.listar(),
    ])
      .then(([cl, ve, mo, ma, ca, lo, man]) => {
        setClientes(cl); setVeiculos(ve); setModelos(mo); setMarcas(ma);
        setCategorias(ca); setLocacoes(lo); setManutencoes(man);
      })
      .catch(() => setErroApi("Não foi possível carregar os dados. O JSON Server está rodando?"));
  }, []);

  const valorDiariaDe = (v?: Veiculo): number => {
    const modelo = modelos.find((m) => m.id === v?.modeloId);
    return categorias.find((c) => c.id === modelo?.categoriaId)?.valorLocacao ?? 0;
  };

  // RN01: só veículos disponíveis (sem locação aberta e sem manutenção em andamento)
  const disponiveis = veiculos.filter(
    (v) => calcularStatusVeiculo(v.id ?? "", locacoes, manutencoes, hojeISO()) === "DISPONIVEL"
  );
  const opcoesVeiculo: OpcaoSelect[] = disponiveis.map((v) => {
    const modelo = modelos.find((m) => m.id === v.modeloId);
    return {
      value: v.id ?? "",
      label: `${v.placa} - ${nomeDe(marcas, modelo?.marcaId ?? "")} ${modelo?.nome ?? ""} (${moeda(valorDiariaDe(v))}/dia)`,
    };
  });

  const veiculoEscolhido = veiculos.find((v) => v.id === form.veiculoId);
  const periodoValido = form.dataRetirada !== "" && form.dataDevolucaoPrevista > form.dataRetirada;
  const diarias = periodoValido ? calcularDiarias(form.dataRetirada, form.dataDevolucaoPrevista) : 0;
  const valorPrevisto = periodoValido
    ? calcularValorLocacao(form.dataRetirada, form.dataDevolucaoPrevista, valorDiariaDe(veiculoEscolhido))
    : 0;

  const alterar = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErros({ ...erros, [e.target.name]: "" });
  };

  const salvar = async (e: FormEvent) => {
    e.preventDefault();
    const cliente = clientes.find((c) => c.id === form.clienteId);

    const novosErros: Record<string, string> = {
      clienteId: !cliente ? "Selecione o cliente." : cnhVencida(cliente) ? "CNH vencida: não é permitido locar para este cliente." : "", // RN03
      veiculoId: form.veiculoId === "" ? "Selecione um veículo disponível." : "",
      dataRetirada: form.dataRetirada === "" ? "Informe a data de retirada." : "",
      dataDevolucaoPrevista:
        form.dataDevolucaoPrevista === "" ? "Informe a data de devolução prevista."
          : !periodoValido ? "A devolução prevista deve ser posterior à retirada." : "", // RN02
    };

    try {
      // RN01: confere de novo no servidor (outra locação pode ter sido aberta)
      if (form.veiculoId !== "") {
        const atuais = await locacaoService.listar();
        if (atuais.some((l) => l.veiculoId === form.veiculoId && l.status === "ABERTA")) {
          novosErros.veiculoId = "Este veículo já possui uma locação em aberto.";
        }
      }
      setErros(novosErros);
      if (Object.values(novosErros).some(Boolean) || !veiculoEscolhido) return;

      const locacao = await locacaoService.criar({
        ...locacaoInicial,
        dataRetirada: form.dataRetirada,
        dataDevolucaoPrevista: form.dataDevolucaoPrevista,
        kmRetirada: veiculoEscolhido.kmRodado,
        valorTotal: valorPrevisto,
        status: "ABERTA",
        clienteId: form.clienteId,
        veiculoId: form.veiculoId,
      });
      const locacaoId = locacao.id ?? "";

      // RF09: contrato gerado automaticamente
      await contratoService.criar({ numero: `CT-${Date.now()}`, dataEmissao: hojeISO(), termos: TERMOS_PADRAO, locacaoId });
      // RF10: vistoria de retirada
      await vistoriaService.criar({
        tipo: "RETIRADA", data: form.dataRetirada, km: veiculoEscolhido.kmRodado,
        nivelCombustivel: form.nivelCombustivel, observacoes: form.observacoes, locacaoId,
      });

      navigate(`/locacoes/${locacaoId}`, { state: { mensagem: "Locação registrada. Contrato e vistoria de retirada gerados." } });
    } catch {
      setErroApi("Erro ao registrar a locação. Verifique se o JSON Server está rodando.");
    }
  };

  return (
    <Card title="Nova locação">
      {erroApi && <Alert type="danger" message={erroApi} onClose={() => setErroApi("")} />}
      <form onSubmit={salvar} noValidate>
        <Select label="Cliente" name="clienteId" value={form.clienteId} error={erros.clienteId}
          options={clientes.map((c) => ({ value: c.id ?? "", label: `${c.nome} - CNH ${c.cnh}` }))} onChange={alterar} />
        <Select label="Veículo disponível" name="veiculoId" value={form.veiculoId} options={opcoesVeiculo}
          error={erros.veiculoId} onChange={alterar} />
        <div className="row">
          <div className="col-md-6">
            <Input label="Data de retirada" name="dataRetirada" type="datetime-local" value={form.dataRetirada}
              onChange={alterar} error={erros.dataRetirada} />
          </div>
          <div className="col-md-6">
            <Input label="Devolução prevista" name="dataDevolucaoPrevista" type="datetime-local"
              value={form.dataDevolucaoPrevista} onChange={alterar} error={erros.dataDevolucaoPrevista} />
          </div>
        </div>

        {veiculoEscolhido && (
          <p className="text-muted">Km de retirada: {veiculoEscolhido.kmRodado.toLocaleString("pt-BR")}</p>
        )}
        <Alert
          type="success"
          message={periodoValido
            ? `${diarias} diária(s) × ${moeda(valorDiariaDe(veiculoEscolhido))} = valor previsto ${moeda(valorPrevisto)}`
            : "Informe as datas e o veículo para calcular o valor previsto."}
        />

        <h6 className="mt-4">Vistoria de retirada</h6>
        <Select label="Nível de combustível" name="nivelCombustivel" value={form.nivelCombustivel}
          options={niveisCombustivel} onChange={alterar} placeholder="Selecione..." />
        <TextArea label="Observações" name="observacoes" value={form.observacoes} onChange={alterar} />

        <div className="d-flex gap-2">
          <Button label="Registrar locação" type="submit" variant="success" />
          <Button label="Cancelar" variant="secondary" onClick={() => navigate("/locacoes")} />
        </div>
      </form>
    </Card>
  );
}

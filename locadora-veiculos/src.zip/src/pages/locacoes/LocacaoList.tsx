import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Alert } from "../../components/Alert";
import { Button } from "../../components/Button";
import { Card } from "../../components/Card";
import { Select } from "../../components/Select";
import { Table } from "../../components/Table";
import type { Coluna } from "../../components/Table";
import type { Cliente } from "../../models/Cliente";
import { formatarData, moeda, nomeDe } from "../../models/formatadores";
import { corStatusLocacao, statusLocacaoOpcoes } from "../../models/Locacao";
import type { Locacao } from "../../models/Locacao";
import type { Veiculo } from "../../models/Veiculo";
import { clienteService } from "../../service/clienteService";
import { locacaoService } from "../../service/locacaoService";
import { veiculoService } from "../../service/veiculoService";

export function LocacaoList() {
  const navigate = useNavigate();
  const location = useLocation();
  const [locacoes, setLocacoes] = useState<Locacao[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [statusFiltro, setStatusFiltro] = useState("");
  const [clienteFiltro, setClienteFiltro] = useState("");
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState((location.state as { mensagem?: string } | null)?.mensagem ?? "");

  useEffect(() => {
    Promise.all([locacaoService.listar(), clienteService.listar(), veiculoService.listar()])
      .then(([l, c, v]) => {
        setLocacoes(l);
        setClientes(c);
        setVeiculos(v);
      })
      .catch(() => setErro("Não foi possível carregar as locações. O JSON Server está rodando?"));
  }, []);

  // RF14: filtro por status e por cliente
  const filtradas = locacoes.filter(
    (l) => (statusFiltro === "" || l.status === statusFiltro) && (clienteFiltro === "" || l.clienteId === clienteFiltro)
  );

  const colunas: Coluna<Locacao>[] = [
    { titulo: "Cliente", render: (l) => nomeDe(clientes, l.clienteId) },
    { titulo: "Veículo", render: (l) => veiculos.find((v) => v.id === l.veiculoId)?.placa ?? "-" },
    { titulo: "Retirada", render: (l) => formatarData(l.dataRetirada) },
    { titulo: "Devolução prevista", render: (l) => formatarData(l.dataDevolucaoPrevista) },
    { titulo: "Valor", render: (l) => moeda(l.valorTotal) },
    { titulo: "Status", render: (l) => <span className={`badge text-bg-${corStatusLocacao[l.status]}`}>{l.status}</span> },
    { titulo: "Detalhes", render: (l) => <Button label="Abrir" size="sm" onClick={() => navigate(`/locacoes/${l.id}`)} /> },
  ];

  return (
    <Card title="Locações">
      {erro && <Alert type="danger" message={erro} onClose={() => setErro("")} />}
      {sucesso && <Alert type="success" message={sucesso} onClose={() => setSucesso("")} />}
      <div className="mb-3">
        <Button label="Nova locação" onClick={() => navigate("/locacoes/nova")} />
      </div>
      <div className="row">
        <div className="col-md-6">
          <Select label="Filtrar por status" name="statusFiltro" value={statusFiltro} placeholder="Todos"
            options={statusLocacaoOpcoes} onChange={(e) => setStatusFiltro(e.target.value)} />
        </div>
        <div className="col-md-6">
          <Select label="Filtrar por cliente" name="clienteFiltro" value={clienteFiltro} placeholder="Todos"
            options={clientes.map((c) => ({ value: c.id ?? "", label: c.nome }))}
            onChange={(e) => setClienteFiltro(e.target.value)} />
        </div>
      </div>
      <Table columns={colunas} data={filtradas} mensagemVazia="Nenhuma locação encontrada." />
    </Card>
  );
}

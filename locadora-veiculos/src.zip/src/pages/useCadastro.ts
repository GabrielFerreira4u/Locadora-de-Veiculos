import { useEffect, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { useNavigate, useParams } from "react-router-dom";
import type { CrudService } from "../service/crudService";

export type Erros = Record<string, string>;

interface Opcoes<T> {
  service: CrudService<T>;
  inicial: T;
  rotaLista: string;
  nome: string;
  validar?: (obj: T, id?: string) => Promise<Erros> | Erros;
}

// Lógica comum dos formulários: carregar (edição), alterar campos, validar e salvar
export function useCadastro<T extends { id?: string }>({ service, inicial, rotaLista, nome, validar }: Opcoes<T>) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [obj, setObj] = useState<T>(inicial);
  const [erros, setErros] = useState<Erros>({});
  const [erroApi, setErroApi] = useState("");

  useEffect(() => {
    if (!id) return;
    service
      .buscarPorId(id)
      .then(setObj)
      .catch(() => setErroApi(`${nome} não encontrado(a) ou API indisponível.`));
  }, [id, service, nome]);

  const alterar = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const numerico = e.target instanceof HTMLInputElement && e.target.type === "number";
    setObj({ ...obj, [name]: numerico ? Number(value) : value });
    setErros({ ...erros, [name]: "" });
  };

  const salvar = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const novosErros = validar ? await validar(obj, id) : {};
      setErros(novosErros);
      if (Object.values(novosErros).some(Boolean)) return;

      if (id) await service.atualizar(id, obj);
      else await service.criar(obj);
      navigate(rotaLista, { state: { mensagem: `${nome} ${id ? "atualizado(a)" : "cadastrado(a)"} com sucesso.` } });
    } catch {
      setErroApi(`Erro ao salvar ${nome.toLowerCase()}. Verifique se o JSON Server está rodando.`);
    }
  };

  return { id, obj, setObj, erros, erroApi, setErroApi, alterar, salvar, cancelar: () => navigate(rotaLista) };
}

import { ListaCrud } from "../../components/ListaCrud";
import type { Coluna } from "../../components/Table";
import { cnhVencida } from "../../models/Cliente";
import type { Cliente } from "../../models/Cliente";
import { formatarData } from "../../models/formatadores";
import { clienteService } from "../../service/clienteService";
import { locacaoService } from "../../service/locacaoService";

const colunas: Coluna<Cliente>[] = [
  { titulo: "Nome", render: (c) => c.nome },
  { titulo: "CPF", render: (c) => c.cpf },
  { titulo: "CNH", render: (c) => c.cnh },
  {
    titulo: "Validade da CNH",
    render: (c) => (
      <>
        {formatarData(c.validadeCnh)} {cnhVencida(c) && <span className="badge text-bg-danger">Vencida</span>}
      </>
    ),
  },
  { titulo: "Telefone", render: (c) => c.telefone },
];

export function ClienteList() {
  return (
    <ListaCrud
      titulo="Clientes"
      nomeEntidade="Cliente"
      rotaBase="/clientes"
      service={clienteService}
      colunas={colunas}
      descrever={(c) => c.nome}
      dependentes={async (c) => {
        const qtd = (await locacaoService.listar()).filter((l) => l.clienteId === c.id).length;
        return qtd > 0 ? `existem ${qtd} locação(ões) vinculada(s) a ele(a)` : null;
      }}
    />
  );
}

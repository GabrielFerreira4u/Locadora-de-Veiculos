import { FormCadastro } from "../../components/FormCadastro";
import { Input } from "../../components/Input";
import { clienteInicial } from "../../models/Cliente";
import type { Cliente } from "../../models/Cliente";
import { clienteService } from "../../service/clienteService";
import { useCadastro } from "../useCadastro";

export function ClienteForm() {
  const { id, obj, erros, erroApi, setErroApi, alterar, salvar, cancelar } = useCadastro<Cliente>({
    service: clienteService,
    inicial: clienteInicial,
    rotaLista: "/clientes",
    nome: "Cliente",
    validar: async (c, idAtual) => {
      const outros = (await clienteService.listar()).filter((x) => x.id !== idAtual);
      return {
        nome: c.nome.trim() === "" ? "Informe o nome." : "",
        cpf: c.cpf.trim() === "" ? "Informe o CPF."
          : outros.some((x) => x.cpf === c.cpf.trim()) ? "Já existe um cliente com este CPF." : "",
        cnh: c.cnh.trim() === "" ? "Informe a CNH."
          : outros.some((x) => x.cnh === c.cnh.trim()) ? "Já existe um cliente com esta CNH." : "",
        validadeCnh: c.validadeCnh === "" ? "Informe a validade da CNH." : "",
        telefone: c.telefone.trim() === "" ? "Informe o telefone." : "",
        email: !c.email.includes("@") ? "Informe um e-mail válido." : "",
        endereco: c.endereco.trim() === "" ? "Informe o endereço." : "",
      };
    },
  });

  return (
    <FormCadastro titulo={id ? "Editar cliente" : "Novo cliente"} erroApi={erroApi}
      onCloseErro={() => setErroApi("")} onSubmit={salvar} onCancel={cancelar}>
      <Input label="Nome" name="nome" value={obj.nome} onChange={alterar} error={erros.nome} />
      <Input label="CPF" name="cpf" value={obj.cpf} onChange={alterar} error={erros.cpf} placeholder="000.000.000-00" />
      <Input label="CNH" name="cnh" value={obj.cnh} onChange={alterar} error={erros.cnh} />
      <Input label="Validade da CNH" name="validadeCnh" type="date" value={obj.validadeCnh} onChange={alterar} error={erros.validadeCnh} />
      <Input label="Telefone" name="telefone" type="tel" value={obj.telefone} onChange={alterar} error={erros.telefone} />
      <Input label="E-mail" name="email" type="email" value={obj.email} onChange={alterar} error={erros.email} />
      <Input label="Endereço" name="endereco" value={obj.endereco} onChange={alterar} error={erros.endereco} />
    </FormCadastro>
  );
}

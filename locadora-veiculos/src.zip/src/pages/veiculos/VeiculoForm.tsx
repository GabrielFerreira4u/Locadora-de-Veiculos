import { useEffect, useState } from "react";
import { FormCadastro } from "../../components/FormCadastro";
import { Input } from "../../components/Input";
import { Select } from "../../components/Select";
import type { OpcaoSelect } from "../../components/Select";
import { nomeDe } from "../../models/formatadores";
import { veiculoInicial } from "../../models/Veiculo";
import type { Veiculo } from "../../models/Veiculo";
import { marcaService } from "../../service/marcaService";
import { modeloService } from "../../service/modeloService";
import { veiculoService } from "../../service/veiculoService";
import { useCadastro } from "../useCadastro";

const repetido = (campo: "placa" | "chassi", valor: string, outros: Veiculo[]): boolean =>
  outros.some((x) => x[campo].toUpperCase() === valor.trim().toUpperCase());

export function VeiculoForm() {
  const [modelos, setModelos] = useState<OpcaoSelect[]>([]);

  const { id, obj, erros, erroApi, setErroApi, alterar, salvar, cancelar } = useCadastro<Veiculo>({
    service: veiculoService,
    inicial: veiculoInicial,
    rotaLista: "/veiculos",
    nome: "Veículo",
    validar: async (v, idAtual) => {
      const outros = (await veiculoService.listar()).filter((x) => x.id !== idAtual);
      return {
        placa: v.placa.trim() === "" ? "Informe a placa."
          : repetido("placa", v.placa, outros) ? "Já existe um veículo com esta placa." : "",
        chassi: v.chassi.trim() === "" ? "Informe o chassi."
          : repetido("chassi", v.chassi, outros) ? "Já existe um veículo com este chassi." : "",
        modeloId: v.modeloId === "" ? "Selecione o modelo." : "",
        cor: v.cor.trim() === "" ? "Informe a cor." : "",
        anoFabricacao: v.anoFabricacao < 1900 ? "Informe um ano válido." : "",
        kmRodado: v.kmRodado < 0 ? "A quilometragem não pode ser negativa." : "",
      };
    },
  });

  useEffect(() => {
    void Promise.all([marcaService.listar(), modeloService.listar()]).then(([marcas, mods]) => {
      setModelos(mods.map((m) => ({ value: m.id ?? "", label: `${nomeDe(marcas, m.marcaId)} ${m.nome} (${m.ano})` })));
    });
  }, []);

  return (
    <FormCadastro titulo={id ? "Editar veículo" : "Novo veículo"} erroApi={erroApi}
      onCloseErro={() => setErroApi("")} onSubmit={salvar} onCancel={cancelar}>
      <Select label="Modelo" name="modeloId" value={obj.modeloId} options={modelos} onChange={alterar} error={erros.modeloId} />
      <Input label="Placa" name="placa" value={obj.placa} onChange={alterar} error={erros.placa} />
      <Input label="Chassi" name="chassi" value={obj.chassi} onChange={alterar} error={erros.chassi} />
      <Input label="Ano de fabricação" name="anoFabricacao" type="number" value={obj.anoFabricacao} onChange={alterar} error={erros.anoFabricacao} />
      <Input label="Cor" name="cor" value={obj.cor} onChange={alterar} error={erros.cor} />
      <Input label="Km rodado" name="kmRodado" type="number" min={0} value={obj.kmRodado} onChange={alterar} error={erros.kmRodado} />
    </FormCadastro>
  );
}

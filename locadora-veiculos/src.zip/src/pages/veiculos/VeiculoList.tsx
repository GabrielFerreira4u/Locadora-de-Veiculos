import { useEffect, useState } from "react";
import { ListaCrud } from "../../components/ListaCrud";
import type { Coluna } from "../../components/Table";
import { hojeISO, nomeDe } from "../../models/formatadores";
import type { Locacao } from "../../models/Locacao";
import type { Manutencao } from "../../models/Manutencao";
import type { Marca } from "../../models/Marca";
import type { Modelo } from "../../models/Modelo";
import { calcularStatusVeiculo, corStatusVeiculo, rotuloStatusVeiculo } from "../../models/Veiculo";
import type { Veiculo } from "../../models/Veiculo";
import { locacaoService } from "../../service/locacaoService";
import { manutencaoService } from "../../service/manutencaoService";
import { marcaService } from "../../service/marcaService";
import { modeloService } from "../../service/modeloService";
import { veiculoService } from "../../service/veiculoService";

export function VeiculoList() {
  const [marcas, setMarcas] = useState<Marca[]>([]);
  const [modelos, setModelos] = useState<Modelo[]>([]);
  const [locacoes, setLocacoes] = useState<Locacao[]>([]);
  const [manutencoes, setManutencoes] = useState<Manutencao[]>([]);

  useEffect(() => {
    void Promise.all([
      marcaService.listar(),
      modeloService.listar(),
      locacaoService.listar(),
      manutencaoService.listar(),
    ]).then(([ma, mo, lo, man]) => {
      setMarcas(ma);
      setModelos(mo);
      setLocacoes(lo);
      setManutencoes(man);
    });
  }, []);

  const descricaoModelo = (v: Veiculo): string => {
    const modelo = modelos.find((m) => m.id === v.modeloId);
    return modelo ? `${nomeDe(marcas, modelo.marcaId)} ${modelo.nome}` : "-";
  };

  const colunas: Coluna<Veiculo>[] = [
    { titulo: "Placa", render: (v) => v.placa },
    { titulo: "Veículo", render: (v) => descricaoModelo(v) },
    { titulo: "Cor", render: (v) => v.cor },
    { titulo: "Ano", render: (v) => v.anoFabricacao },
    { titulo: "Km", render: (v) => v.kmRodado.toLocaleString("pt-BR") },
    {
      titulo: "Situação",
      render: (v) => {
        const status = calcularStatusVeiculo(v.id ?? "", locacoes, manutencoes, hojeISO());
        return <span className={`badge text-bg-${corStatusVeiculo[status]}`}>{rotuloStatusVeiculo[status]}</span>;
      },
    },
  ];

  return (
    <ListaCrud
      titulo="Veículos"
      nomeEntidade="Veículo"
      rotaBase="/veiculos"
      service={veiculoService}
      colunas={colunas}
      descrever={(v) => v.placa}
      dependentes={async (v) => {
        const [man, loc] = await Promise.all([manutencaoService.listar(), locacaoService.listar()]);
        const qtdMan = man.filter((m) => m.veiculoId === v.id).length;
        const qtdLoc = loc.filter((l) => l.veiculoId === v.id).length;
        return qtdMan + qtdLoc === 0 ? null : `há ${qtdMan} manutenção(ões) e ${qtdLoc} locação(ões) vinculada(s) a ele`;
      }}
    />
  );
}

import { useNavigate } from "react-router-dom";

const atalhos = [
  {
    titulo: "Veículos",
    descricao: "Consulte e mantenha sua frota sempre atualizada.",
    imagem:
      "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=85",
    alt: "Carro moderno estacionado",
    acao: "Explorar veículos",
    destino: "/veiculos",
  },
  {
    titulo: "Clientes",
    descricao: "Acesse os cadastros e encontre clientes rapidamente.",
    imagem:
      "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=900&q=85",
    alt: "Interior de um carro",
    acao: "Ver clientes",
    destino: "/clientes",
  },
  {
    titulo: "Locações",
    descricao: "Acompanhe contratos, retiradas e devoluções.",
    imagem:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=900&q=85",
    alt: "Carro esportivo em uma estrada",
    acao: "Gerenciar locações",
    destino: "/locacoes",
  },
];

export function Home() {
  const navigate = useNavigate();

  return (
    <div className="home-page">
      <section className="home-hero mb-5">
        <img
          className="home-hero-image"
          src="https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&w=2000&q=90"
          alt="Veículo em uma oficina, pronto para revisão"
        />
        <div className="home-hero-content">
          <span className="home-eyebrow">PAINEL DE CONTROLE</span>
          <h1>Sua frota, sob controle.</h1>
          <p>
            Gerencie veículos, clientes e locações em um só lugar. Mais praticidade
            para cuidar de cada etapa do seu negócio.
          </p>
          <button
            className="btn btn-light btn-lg home-hero-button"
            onClick={() => navigate("/locacoes/nova")}
          >
            Iniciar uma locação <span aria-hidden="true">→</span>
          </button>
        </div>
      </section>

      <section aria-labelledby="atalhos-titulo">
        <div className="d-flex flex-column flex-sm-row justify-content-between align-items-sm-end gap-2 mb-3">
          <div>
            <span className="home-section-eyebrow">ACESSO RÁPIDO</span>
            <h2 id="atalhos-titulo" className="home-section-title mb-0">
              O que você precisa hoje?
            </h2>
          </div>
          <p className="text-secondary mb-1">Escolha uma área para continuar</p>
        </div>

        <div className="row g-4">
          {atalhos.map((atalho) => (
            <div className="col-12 col-md-6 col-xl-4" key={atalho.destino}>
              <article className="card home-shortcut h-100">
                <img
                  src={atalho.imagem}
                  className="card-img-top home-shortcut-image"
                  alt={atalho.alt}
                  loading="lazy"
                />
                <div className="card-body d-flex flex-column p-4">
                  <h3 className="card-title">{atalho.titulo}</h3>
                  <p className="card-text text-secondary flex-grow-1">{atalho.descricao}</p>
                  <button
                    className="btn btn-outline-primary align-self-start"
                    onClick={() => navigate(atalho.destino)}
                  >
                    {atalho.acao} <span aria-hidden="true">→</span>
                  </button>
                </div>
              </article>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

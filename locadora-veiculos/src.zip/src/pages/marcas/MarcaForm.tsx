import { useEffect, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Alert } from "../../components/Alert";
import { Button } from "../../components/Button";
import { Card } from "../../components/Card";
import { Input } from "../../components/Input";
import { marcaInicial } from "../../models/Marca";
import type { Marca } from "../../models/Marca";
import { marcaService } from "../../service/marcaService";

export function MarcaForm() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [marca, setMarca] = useState<Marca>(marcaInicial);
  const [erroNome, setErroNome] = useState("");
  const [erroApi, setErroApi] = useState("");

  useEffect(() => {
    if (!id) return;
    marcaService
      .buscarPorId(id)
      .then(setMarca)
      .catch(() => setErroApi("Marca não encontrada ou API indisponível."));
  }, [id]);

  const aoAlterar = (e: ChangeEvent<HTMLInputElement>) => {
    setMarca({ ...marca, [e.target.name]: e.target.value });
    setErroNome("");
  };

  const aoSalvar = async (e: FormEvent) => {
    e.preventDefault();

    if (marca.nome.trim() === "") {
      setErroNome("Informe o nome da marca.");
      return;
    }

    try {
      const dados: Marca = { ...marca, nome: marca.nome.trim() };
      if (id) {
        await marcaService.atualizar(id, dados);
      } else {
        await marcaService.criar(dados);
      }
      navigate("/marcas", {
        state: { mensagem: id ? "Marca atualizada com sucesso." : "Marca cadastrada com sucesso." },
      });
    } catch {
      setErroApi("Erro ao salvar a marca. Verifique se o JSON Server está rodando.");
    }
  };

  return (
    <Card title={id ? "Editar marca" : "Nova marca"}>
      {erroApi && <Alert type="danger" message={erroApi} onClose={() => setErroApi("")} />}

      <form onSubmit={aoSalvar} noValidate>
        <Input label="Nome" name="nome" value={marca.nome} onChange={aoAlterar} error={erroNome} />
        <div className="d-flex gap-2">
          <Button label="Salvar" type="submit" variant="success" />
          <Button label="Cancelar" variant="secondary" onClick={() => navigate("/marcas")} />
        </div>
      </form>
    </Card>
  );
}

import { useCallback, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Alert } from "../../components/Alert";
import { Button } from "../../components/Button";
import { Card } from "../../components/Card";
import { Modal } from "../../components/Modal";
import { Table } from "../../components/Table";
import type { Coluna } from "../../components/Table";
import type { Marca } from "../../models/Marca";
import { marcaService } from "../../service/marcaService";
import { modeloService } from "../../service/modeloService";

interface Mensagem {
  type: "success" | "danger" | "warning";
  texto: string;
}

const colunas: Coluna<Marca>[] = [
  { titulo: "ID", render: (m) => m.id },
  { titulo: "Nome", render: (m) => m.nome },
];

export function MarcaList() {
  const navigate = useNavigate();
  const location = useLocation();
  const textoInicial = (location.state as { mensagem?: string } | null)?.mensagem;

  const [marcas, setMarcas] = useState<Marca[]>([]);
  const [mensagem, setMensagem] = useState<Mensagem | null>(
    textoInicial ? { type: "success", texto: textoInicial } : null
  );
  const [marcaParaExcluir, setMarcaParaExcluir] = useState<Marca | null>(null);

  const carregar = useCallback(async () => {
    try {
      setMarcas(await marcaService.listar());
    } catch {
      setMensagem({ type: "danger", texto: "Não foi possível carregar as marcas. O JSON Server está rodando?" });
    }
  }, []);

  useEffect(() => {
    void carregar();
  }, [carregar]);

  const confirmarExclusao = async () => {
    if (!marcaParaExcluir?.id) return;
    const marca = marcaParaExcluir;
    setMarcaParaExcluir(null);

    try {
      // RN06: não excluir registro que possui dependentes
      const modelos = await modeloService.listar();
      const dependentes = modelos.filter((modelo) => modelo.marcaId === marca.id);
      if (dependentes.length > 0) {
        setMensagem({
          type: "danger",
          texto: `Não é possível excluir "${marca.nome}": existem ${dependentes.length} modelo(s) vinculado(s) a ela.`,
        });
        return;
      }

      await marcaService.excluir(marca.id as string);
      setMensagem({ type: "success", texto: `Marca "${marca.nome}" excluída com sucesso.` });
      await carregar();
    } catch {
      setMensagem({ type: "danger", texto: "Erro ao excluir a marca." });
    }
  };

  return (
    <Card title="Marcas">
      {mensagem && (
        <Alert type={mensagem.type} message={mensagem.texto} onClose={() => setMensagem(null)} />
      )}

      <div className="mb-3">
        <Button label="Nova marca" onClick={() => navigate("/marcas/novo")} />
      </div>

      <Table
        columns={colunas}
        data={marcas}
        onEdit={(marca) => navigate(`/marcas/${marca.id}/editar`)}
        onDelete={(marca) => setMarcaParaExcluir(marca)}
      />

      <Modal
        show={marcaParaExcluir !== null}
        title="Confirmar exclusão"
        message={`Deseja realmente excluir a marca "${marcaParaExcluir?.nome ?? ""}"?`}
        onClose={() => setMarcaParaExcluir(null)}
        onConfirm={confirmarExclusao}
      />
    </Card>
  );
}

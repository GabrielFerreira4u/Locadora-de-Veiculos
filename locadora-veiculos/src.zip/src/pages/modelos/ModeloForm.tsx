import { useEffect, useState } from "react";
import { FormCadastro } from "../../components/FormCadastro";
import { Input } from "../../components/Input";
import { Select } from "../../components/Select";
import type { OpcaoSelect } from "../../components/Select";
import { modeloInicial } from "../../models/Modelo";
import type { Modelo } from "../../models/Modelo";
import { categoriaService } from "../../service/categoriaService";
import { marcaService } from "../../service/marcaService";
import { modeloService } from "../../service/modeloService";
import { useCadastro } from "../useCadastro";

export function ModeloForm() {
  const [marcas, setMarcas] = useState<OpcaoSelect[]>([]);
  const [categorias, setCategorias] = useState<OpcaoSelect[]>([]);

  const { id, obj, erros, erroApi, setErroApi, alterar, salvar, cancelar } = useCadastro<Modelo>({
    service: modeloService,
    inicial: modeloInicial,
    rotaLista: "/modelos",
    nome: "Modelo",
    validar: (m) => ({
      nome: m.nome.trim() === "" ? "Informe o nome do modelo." : "",
      ano: m.ano < 1900 ? "Informe um ano válido." : "",
      marcaId: m.marcaId === "" ? "Selecione a marca." : "",
      categoriaId: m.categoriaId === "" ? "Selecione a categoria." : "",
    }),
  });

  useEffect(() => {
    void Promise.all([marcaService.listar(), categoriaService.listar()]).then(([m, c]) => {
      setMarcas(m.map((x) => ({ value: x.id ?? "", label: x.nome })));
      setCategorias(c.map((x) => ({ value: x.id ?? "", label: x.nome })));
    });
  }, []);

  return (
    <FormCadastro titulo={id ? "Editar modelo" : "Novo modelo"} erroApi={erroApi}
      onCloseErro={() => setErroApi("")} onSubmit={salvar} onCancel={cancelar}>
      <Input label="Nome" name="nome" value={obj.nome} onChange={alterar} error={erros.nome} />
      <Input label="Ano" name="ano" type="number" value={obj.ano} onChange={alterar} error={erros.ano} />
      <Select label="Marca" name="marcaId" value={obj.marcaId} options={marcas} onChange={alterar} error={erros.marcaId} />
      <Select label="Categoria" name="categoriaId" value={obj.categoriaId} options={categorias} onChange={alterar} error={erros.categoriaId} />
    </FormCadastro>
  );
}

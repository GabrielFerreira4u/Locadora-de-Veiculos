import { useEffect, useState } from "react";
import { ListaCrud } from "../../components/ListaCrud";
import type { Coluna } from "../../components/Table";
import type { Categoria } from "../../models/Categoria";
import { nomeDe } from "../../models/formatadores";
import type { Marca } from "../../models/Marca";
import type { Modelo } from "../../models/Modelo";
import { categoriaService } from "../../service/categoriaService";
import { marcaService } from "../../service/marcaService";
import { modeloService } from "../../service/modeloService";
import { veiculoService } from "../../service/veiculoService";

export function ModeloList() {
  const [marcas, setMarcas] = useState<Marca[]>([]);
  const [categorias, setCategorias] = useState<Categoria[]>([]);

  useEffect(() => {
    void Promise.all([marcaService.listar(), categoriaService.listar()]).then(([m, c]) => {
      setMarcas(m);
      setCategorias(c);
    });
  }, []);

  const colunas: Coluna<Modelo>[] = [
    { titulo: "ID", render: (m) => m.id },
    { titulo: "Nome", render: (m) => m.nome },
    { titulo: "Ano", render: (m) => m.ano },
    { titulo: "Marca", render: (m) => nomeDe(marcas, m.marcaId) },
    { titulo: "Categoria", render: (m) => nomeDe(categorias, m.categoriaId) },
  ];

  return (
    <ListaCrud
      titulo="Modelos"
      nomeEntidade="Modelo"
      rotaBase="/modelos"
      service={modeloService}
      colunas={colunas}
      descrever={(m) => m.nome}
      dependentes={async (m) => {
        const qtd = (await veiculoService.listar()).filter((v) => v.modeloId === m.id).length;
        return qtd > 0 ? `existem ${qtd} veículo(s) vinculado(s) a ele` : null;
      }}
    />
  );
}

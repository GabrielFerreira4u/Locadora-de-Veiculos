import type { NotaFiscal } from "../models/NotaFiscal";
import { criarCrudService } from "./crudService";

export const notaFiscalService = criarCrudService<NotaFiscal>("/notasFiscais");

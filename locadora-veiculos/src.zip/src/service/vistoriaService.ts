import type { Vistoria } from "../models/Vistoria";
import { criarCrudService } from "./crudService";

export const vistoriaService = criarCrudService<Vistoria>("/vistorias");

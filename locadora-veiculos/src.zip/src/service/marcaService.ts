import type { Marca } from "../models/Marca";
import { criarCrudService } from "./crudService";

export const marcaService = criarCrudService<Marca>("/marcas");

import type { Modelo } from "../models/Modelo";
import { criarCrudService } from "./crudService";

export const modeloService = criarCrudService<Modelo>("/modelos");

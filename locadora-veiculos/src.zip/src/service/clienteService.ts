import type { Cliente } from "../models/Cliente";
import { criarCrudService } from "./crudService";

export const clienteService = criarCrudService<Cliente>("/clientes");

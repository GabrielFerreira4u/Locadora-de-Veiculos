import type { Veiculo } from "../models/Veiculo";
import { criarCrudService } from "./crudService";

export const veiculoService = criarCrudService<Veiculo>("/veiculos");

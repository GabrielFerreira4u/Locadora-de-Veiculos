import type { Pagamento } from "../models/Pagamento";
import { criarCrudService } from "./crudService";

export const pagamentoService = criarCrudService<Pagamento>("/pagamentos");

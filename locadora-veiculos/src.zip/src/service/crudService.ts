import { api } from "./api";

// Contrato comum a todos os serviços (um por entidade)
export interface CrudService<T> {
  listar: () => Promise<T[]>;
  buscarPorId: (id: string) => Promise<T>;
  criar: (obj: T) => Promise<T>;
  atualizar: (id: string, obj: T) => Promise<T>;
  excluir: (id: string) => Promise<void>;
}

// Fábrica genérica: evita repetir as mesmas 5 funções em cada serviço
export function criarCrudService<T>(rota: string): CrudService<T> {
  return {
    listar: async (): Promise<T[]> => (await api.get<T[]>(rota)).data,
    buscarPorId: async (id: string): Promise<T> => (await api.get<T>(`${rota}/${id}`)).data,
    criar: async (obj: T): Promise<T> => (await api.post<T>(rota, obj)).data,
    atualizar: async (id: string, obj: T): Promise<T> => (await api.put<T>(`${rota}/${id}`, obj)).data,
    excluir: async (id: string): Promise<void> => {
      await api.delete(`${rota}/${id}`);
    },
  };
}

import type { Categoria } from "../models/Categoria";
import { criarCrudService } from "./crudService";

export const categoriaService = criarCrudService<Categoria>("/categorias");

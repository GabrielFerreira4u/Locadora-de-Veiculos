import type { Manutencao } from "../models/Manutencao";
import { criarCrudService } from "./crudService";

export const manutencaoService = criarCrudService<Manutencao>("/manutencoes");

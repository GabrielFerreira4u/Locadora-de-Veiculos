import type { Contrato } from "../models/Contrato";
import { criarCrudService } from "./crudService";

export const contratoService = criarCrudService<Contrato>("/contratos");

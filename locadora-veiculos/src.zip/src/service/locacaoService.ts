import type { Locacao } from "../models/Locacao";
import { criarCrudService } from "./crudService";

export const locacaoService = criarCrudService<Locacao>("/locacoes");

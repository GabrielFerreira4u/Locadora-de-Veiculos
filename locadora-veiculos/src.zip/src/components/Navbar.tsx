import { useState } from "react";
import { NavLink } from "react-router-dom";

export interface LinkMenu {
  to: string;
  label: string;
}

interface NavbarProps {
  links: LinkMenu[];
}

export function Navbar({ links }: NavbarProps) {
  const [aberto, setAberto] = useState(false);

  return (
    <nav className="navbar navbar-expand-lg navbar-dark app-navbar mb-4">
      <div className="container">
        <NavLink className="navbar-brand app-navbar-brand" to="/">
          <span className="app-brand-mark" aria-hidden="true">L</span>
          Locadora <span className="app-brand-light">de Veículos</span>
        </NavLink>
        <button
          className="navbar-toggler"
          type="button"
          aria-label="Abrir menu"
          aria-expanded={aberto}
          onClick={() => setAberto(!aberto)}
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className={`collapse navbar-collapse${aberto ? " show" : ""}`}>
          <ul className="navbar-nav ms-auto">
            {links.map((link) => (
              <li className="nav-item" key={link.to}>
                <NavLink
                  className={({ isActive }) => `nav-link${isActive ? " active fw-semibold" : ""}`}
                  to={link.to}
                  end={link.to === "/"}
                  onClick={() => setAberto(false)}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </nav>
  );
}

import { Button } from "./Button";

interface ModalProps {
  show: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  onClose: () => void;
  onConfirm: () => void;
}

// Modal de confirmação (ex.: exclusão), feito só com as classes do Bootstrap
export function Modal({ show, title, message, confirmLabel = "Excluir", onClose, onConfirm }: ModalProps) {
  if (!show) return null;

  return (
    <>
      <div className="modal d-block" tabIndex={-1} role="dialog">
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{title}</h5>
            </div>
            <div className="modal-body">
              <p className="mb-0">{message}</p>
            </div>
            <div className="modal-footer">
              <Button label="Cancelar" variant="secondary" onClick={onClose} />
              <Button label={confirmLabel} variant="danger" onClick={onConfirm} />
            </div>
          </div>
        </div>
      </div>
      <div className="modal-backdrop show" />
    </>
  );
}

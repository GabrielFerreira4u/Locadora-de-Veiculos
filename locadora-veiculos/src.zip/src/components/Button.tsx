interface ButtonProps {
  label: string;
  variant?: "primary" | "secondary" | "success" | "danger" | "warning";
  type?: "button" | "submit";
  size?: "sm" | "lg";
  disabled?: boolean;
  onClick?: () => void;
}

export function Button({ label, variant = "primary", type = "button", size, disabled, onClick }: ButtonProps) {
  const classe = `btn btn-${variant}${size ? ` btn-${size}` : ""}`;
  return (
    <button type={type} className={classe} disabled={disabled} onClick={onClick}>
      {label}
    </button>
  );
}

interface AlertProps {
  type: "success" | "danger" | "warning";
  message: string;
  onClose?: () => void;
}

export function Alert({ type, message, onClose }: AlertProps) {
  return (
    <div className={`alert alert-${type}${onClose ? " alert-dismissible" : ""}`} role="alert">
      {message}
      {onClose && <button type="button" className="btn-close" aria-label="Fechar" onClick={onClose} />}
    </div>
  );
}

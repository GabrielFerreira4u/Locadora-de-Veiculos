import type { ChangeEvent } from "react";

interface InputProps {
  label: string;
  name: string;
  type?: "text" | "number" | "date" | "datetime-local" | "email" | "tel";
  value: string | number;
  onChange: (e: ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  error?: string;
  min?: number;
  step?: number;
  disabled?: boolean;
}

export function Input({ label, name, type = "text", value, onChange, placeholder, error, min, step, disabled }: InputProps) {
  return (
    <div className="mb-3">
      <label htmlFor={name} className="form-label">{label}</label>
      <input
        id={name}
        name={name}
        type={type}
        className={`form-control${error ? " is-invalid" : ""}`}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        min={min}
        step={step}
        disabled={disabled}
      />
      {error && <div className="invalid-feedback">{error}</div>}
    </div>
  );
}

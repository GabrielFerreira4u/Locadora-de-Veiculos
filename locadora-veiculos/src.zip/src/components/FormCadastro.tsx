import type { FormEvent, ReactNode } from "react";
import { Alert } from "./Alert";
import { Button } from "./Button";
import { Card } from "./Card";

interface FormCadastroProps {
  titulo: string;
  erroApi?: string;
  onCloseErro?: () => void;
  onSubmit: (e: FormEvent) => void;
  onCancel: () => void;
  children: ReactNode;
}

// Estrutura comum dos formulários de cadastro
export function FormCadastro({ titulo, erroApi, onCloseErro, onSubmit, onCancel, children }: FormCadastroProps) {
  return (
    <Card title={titulo}>
      {erroApi && <Alert type="danger" message={erroApi} onClose={onCloseErro} />}
      <form onSubmit={onSubmit} noValidate>
        {children}
        <div className="d-flex gap-2">
          <Button label="Salvar" type="submit" variant="success" />
          <Button label="Cancelar" variant="secondary" onClick={onCancel} />
        </div>
      </form>
    </Card>
  );
}

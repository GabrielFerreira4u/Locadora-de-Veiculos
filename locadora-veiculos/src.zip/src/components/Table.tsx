import type { ReactNode } from "react";
import { Button } from "./Button";

export interface Coluna<T> {
  titulo: string;
  render: (item: T) => ReactNode;
}

interface TableProps<T> {
  columns: Coluna<T>[];
  data: T[];
  onEdit?: (item: T) => void;
  onDelete?: (item: T) => void;
  mensagemVazia?: string;
}

// Tabela genérica: serve para qualquer entidade que tenha "id"
export function Table<T extends { id?: string }>({
  columns,
  data,
  onEdit,
  onDelete,
  mensagemVazia = "Nenhum registro encontrado.",
}: TableProps<T>) {
  const temAcoes = Boolean(onEdit || onDelete);

  return (
    <div className="table-responsive">
      <table className="table table-striped table-hover align-middle">
        <thead className="table-light">
          <tr>
            {columns.map((coluna) => (
              <th key={coluna.titulo}>{coluna.titulo}</th>
            ))}
            {temAcoes && <th className="text-end">Ações</th>}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 && (
            <tr>
              <td colSpan={columns.length + (temAcoes ? 1 : 0)} className="text-center text-muted py-4">
                {mensagemVazia}
              </td>
            </tr>
          )}
          {data.map((item, indice) => (
            <tr key={item.id ?? indice}>
              {columns.map((coluna) => (
                <td key={coluna.titulo}>{coluna.render(item)}</td>
              ))}
              {temAcoes && (
                <td className="text-end text-nowrap">
                  {onEdit && <Button label="Editar" variant="warning" size="sm" onClick={() => onEdit(item)} />}{" "}
                  {onDelete && <Button label="Excluir" variant="danger" size="sm" onClick={() => onDelete(item)} />}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

import { useCallback, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import type { CrudService } from "../service/crudService";
import { Alert } from "./Alert";
import { Button } from "./Button";
import { Card } from "./Card";
import { Modal } from "./Modal";
import { Table } from "./Table";
import type { Coluna } from "./Table";

interface Mensagem {
  type: "success" | "danger" | "warning";
  texto: string;
}

interface ListaCrudProps<T extends { id?: string }> {
  titulo: string;
  nomeEntidade: string;
  rotaBase: string;
  service: CrudService<T>;
  colunas: Coluna<T>[];
  descrever: (item: T) => string;
  // RN06: devolve o motivo do bloqueio (ou null se puder excluir)
  dependentes?: (item: T) => Promise<string | null>;
  filtro?: (item: T) => boolean;
  topo?: ReactNode;
  recarregarQuando?: unknown;
}

// Listagem padrão: tabela + editar/excluir com confirmação e verificação de dependentes
export function ListaCrud<T extends { id?: string }>({
  titulo,
  nomeEntidade,
  rotaBase,
  service,
  colunas,
  descrever,
  dependentes,
  filtro,
  topo,
  recarregarQuando,
}: ListaCrudProps<T>) {
  const navigate = useNavigate();
  const location = useLocation();
  const textoInicial = (location.state as { mensagem?: string } | null)?.mensagem;

  const [itens, setItens] = useState<T[]>([]);
  const [mensagem, setMensagem] = useState<Mensagem | null>(
    textoInicial ? { type: "success", texto: textoInicial } : null
  );
  const [paraExcluir, setParaExcluir] = useState<T | null>(null);

  const carregar = useCallback(async () => {
    try {
      setItens(await service.listar());
    } catch {
      setMensagem({ type: "danger", texto: "Não foi possível carregar os dados. O JSON Server está rodando?" });
    }
  }, [service]);

  useEffect(() => {
    void carregar();
  }, [carregar, recarregarQuando]);

  const confirmarExclusao = async () => {
    if (!paraExcluir?.id) return;
    const item = paraExcluir;
    setParaExcluir(null);
    try {
      const motivo = dependentes ? await dependentes(item) : null;
      if (motivo) {
        setMensagem({ type: "danger", texto: `Não é possível excluir "${descrever(item)}": ${motivo}.` });
        return;
      }
      await service.excluir(item.id ?? "");
      setMensagem({ type: "success", texto: `${nomeEntidade} "${descrever(item)}" excluído(a) com sucesso.` });
      await carregar();
    } catch {
      setMensagem({ type: "danger", texto: `Erro ao excluir ${nomeEntidade.toLowerCase()}.` });
    }
  };

  return (
    <Card title={titulo}>
      {mensagem && <Alert type={mensagem.type} message={mensagem.texto} onClose={() => setMensagem(null)} />}
      <div className="mb-3">
        <Button label={`Novo(a) ${nomeEntidade.toLowerCase()}`} onClick={() => navigate(`${rotaBase}/novo`)} />
      </div>
      {topo}
      <Table
        columns={colunas}
        data={filtro ? itens.filter(filtro) : itens}
        onEdit={(item) => navigate(`${rotaBase}/${item.id}/editar`)}
        onDelete={(item) => setParaExcluir(item)}
      />
      <Modal
        show={paraExcluir !== null}
        title="Confirmar exclusão"
        message={`Deseja realmente excluir "${paraExcluir ? descrever(paraExcluir) : ""}"?`}
        onClose={() => setParaExcluir(null)}
        onConfirm={confirmarExclusao}
      />
    </Card>
  );
}

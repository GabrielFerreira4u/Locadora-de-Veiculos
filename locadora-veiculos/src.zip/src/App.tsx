import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Navbar } from "./components/Navbar";
import type { LinkMenu } from "./components/Navbar";
import { CategoriaForm } from "./pages/categorias/CategoriaForm";
import { CategoriaList } from "./pages/categorias/CategoriaList";
import { ClienteForm } from "./pages/clientes/ClienteForm";
import { ClienteList } from "./pages/clientes/ClienteList";
import { Home } from "./pages/Home";
import { DevolucaoForm } from "./pages/locacoes/DevolucaoForm";
import { LocacaoDetalhe } from "./pages/locacoes/LocacaoDetalhe";
import { LocacaoForm } from "./pages/locacoes/LocacaoForm";
import { LocacaoList } from "./pages/locacoes/LocacaoList";
import { ManutencaoForm } from "./pages/manutencoes/ManutencaoForm";
import { ManutencaoList } from "./pages/manutencoes/ManutencaoList";
import { MarcaForm } from "./pages/marcas/MarcaForm";
import { MarcaList } from "./pages/marcas/MarcaList";
import { ModeloForm } from "./pages/modelos/ModeloForm";
import { ModeloList } from "./pages/modelos/ModeloList";
import { VeiculoForm } from "./pages/veiculos/VeiculoForm";
import { VeiculoList } from "./pages/veiculos/VeiculoList";

const links: LinkMenu[] = [
  { to: "/", label: "Início" },
  { to: "/marcas", label: "Marcas" },
  { to: "/categorias", label: "Categorias" },
  { to: "/modelos", label: "Modelos" },
  { to: "/veiculos", label: "Veículos" },
  { to: "/manutencoes", label: "Manutenções" },
  { to: "/clientes", label: "Clientes" },
  { to: "/locacoes", label: "Locações" },
];

export default function App() {
  return (
    <BrowserRouter>
      <Navbar links={links} />
      <main className="container pb-5">
        <Routes>
          <Route path="/" element={<Home />} />

          <Route path="/marcas" element={<MarcaList />} />
          <Route path="/marcas/novo" element={<MarcaForm />} />
          <Route path="/marcas/:id/editar" element={<MarcaForm />} />

          <Route path="/categorias" element={<CategoriaList />} />
          <Route path="/categorias/novo" element={<CategoriaForm />} />
          <Route path="/categorias/:id/editar" element={<CategoriaForm />} />

          <Route path="/modelos" element={<ModeloList />} />
          <Route path="/modelos/novo" element={<ModeloForm />} />
          <Route path="/modelos/:id/editar" element={<ModeloForm />} />

          <Route path="/veiculos" element={<VeiculoList />} />
          <Route path="/veiculos/novo" element={<VeiculoForm />} />
          <Route path="/veiculos/:id/editar" element={<VeiculoForm />} />

          <Route path="/manutencoes" element={<ManutencaoList />} />
          <Route path="/manutencoes/novo" element={<ManutencaoForm />} />
          <Route path="/manutencoes/:id/editar" element={<ManutencaoForm />} />

          <Route path="/clientes" element={<ClienteList />} />
          <Route path="/clientes/novo" element={<ClienteForm />} />
          <Route path="/clientes/:id/editar" element={<ClienteForm />} />

          <Route path="/locacoes" element={<LocacaoList />} />
          <Route path="/locacoes/nova" element={<LocacaoForm />} />
          <Route path="/locacoes/:id" element={<LocacaoDetalhe />} />
          <Route path="/locacoes/:id/devolucao" element={<DevolucaoForm />} />

          <Route path="*" element={<p className="text-muted">Página não encontrada.</p>} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}

const p = (n: number): string => String(n).padStart(2, "0");

// "yyyy-mm-dd" no fuso local
export const hojeISO = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

// "yyyy-mm-ddThh:mm" (formato do input datetime-local)
export const agoraLocal = (): string => {
  const d = new Date();
  return `${hojeISO()}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

export const moeda = (valor: number): string =>
  valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export const formatarData = (iso?: string): string => {
  if (!iso) return "-";
  if (iso.length === 10) return new Date(`${iso}T00:00`).toLocaleDateString("pt-BR");
  return new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
};

export function nomeDe<T extends { id?: string; nome: string }>(lista: T[], id: string): string {
  return lista.find((item) => item.id === id)?.nome ?? "-";
}

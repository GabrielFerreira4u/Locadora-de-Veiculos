export type StatusLocacao = "ABERTA" | "FINALIZADA" | "CANCELADA";

export interface Locacao {
  id?: string;
  dataRetirada: string;
  dataDevolucaoPrevista: string;
  dataDevolucaoReal?: string;
  kmRetirada: number;
  kmDevolucao?: number;
  valorTotal: number;
  status: StatusLocacao;
  clienteId: string;
  veiculoId: string;
}

export const locacaoInicial: Locacao = {
  dataRetirada: "",
  dataDevolucaoPrevista: "",
  kmRetirada: 0,
  valorTotal: 0,
  status: "ABERTA",
  clienteId: "",
  veiculoId: "",
};

const MS_POR_DIA = 24 * 60 * 60 * 1000;

// nº de diárias (mínimo 1; fração de dia conta como uma diária a mais)
export function calcularDiarias(retirada: string, devolucao: string): number {
  const diferenca = new Date(devolucao).getTime() - new Date(retirada).getTime();
  return Math.max(1, Math.ceil(diferenca / MS_POR_DIA));
}

// RF08: nº de diárias × valor da diária da categoria
export function calcularValorLocacao(retirada: string, devolucao: string, valorDiaria: number): number {
  return calcularDiarias(retirada, devolucao) * valorDiaria;
}

export const statusLocacaoOpcoes: { value: StatusLocacao; label: string }[] = [
  { value: "ABERTA", label: "Aberta" },
  { value: "FINALIZADA", label: "Finalizada" },
  { value: "CANCELADA", label: "Cancelada" },
];

export const corStatusLocacao: Record<StatusLocacao, string> = {
  ABERTA: "primary",
  FINALIZADA: "success",
  CANCELADA: "secondary",
};

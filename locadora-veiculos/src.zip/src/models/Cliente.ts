export interface Cliente {
  id?: string;
  nome: string;
  cpf: string;
  cnh: string;
  validadeCnh: string; // yyyy-mm-dd
  telefone: string;
  email: string;
  endereco: string;
}

export const clienteInicial: Cliente = {
  nome: "",
  cpf: "",
  cnh: "",
  validadeCnh: "",
  telefone: "",
  email: "",
  endereco: "",
};

// RN03: CNH vencida não pode alugar
export function cnhVencida(cliente: Cliente, hoje: Date = new Date()): boolean {
  const validade = new Date(`${cliente.validadeCnh}T23:59:59`);
  return validade < hoje;
}

export interface NotaFiscal {
  id?: string;
  numero: string;
  serie: string;
  dataEmissao: string;
  valor: number;
  locacaoId: string;
}

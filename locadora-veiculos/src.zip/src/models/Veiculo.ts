import type { Locacao } from "./Locacao";
import type { Manutencao } from "./Manutencao";

export type StatusVeiculo = "DISPONIVEL" | "LOCADO" | "MANUTENCAO";

export interface Veiculo {
  id?: string;
  chassi: string;
  placa: string;
  anoFabricacao: number;
  cor: string;
  kmRodado: number;
  modeloId: string;
}

export const veiculoInicial: Veiculo = {
  chassi: "",
  placa: "",
  anoFabricacao: new Date().getFullYear(),
  cor: "",
  kmRodado: 0,
  modeloId: "",
};

export const rotuloStatusVeiculo: Record<StatusVeiculo, string> = {
  DISPONIVEL: "Disponível",
  LOCADO: "Locado",
  MANUTENCAO: "Em manutenção",
};

export const corStatusVeiculo: Record<StatusVeiculo, string> = {
  DISPONIVEL: "success",
  LOCADO: "warning",
  MANUTENCAO: "secondary",
};

// RF16: locado = tem locação aberta; em manutenção = tem manutenção com data de hoje ou futura
export function calcularStatusVeiculo(
  veiculoId: string,
  locacoes: Locacao[],
  manutencoes: Manutencao[],
  hoje: string
): StatusVeiculo {
  if (locacoes.some((l) => l.veiculoId === veiculoId && l.status === "ABERTA")) return "LOCADO";
  if (manutencoes.some((m) => m.veiculoId === veiculoId && m.data >= hoje)) return "MANUTENCAO";
  return "DISPONIVEL";
}

export interface Categoria {
  id?: string;
  nome: string;
  valorLocacao: number; // valor da diária
}

export const categoriaInicial: Categoria = {
  nome: "",
  valorLocacao: 0,
};
